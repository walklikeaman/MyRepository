package telran.ashkelon2018.forum.dto;

import lombok.Getter;

@Getter
public class UserRegDto {
	String firstName;
	String lastName;
}
