package telran.ashkelon2018.forum.dto;

import lombok.Getter;

@Getter
public class PostUpdateDto {
	String id;
	String content;

}
