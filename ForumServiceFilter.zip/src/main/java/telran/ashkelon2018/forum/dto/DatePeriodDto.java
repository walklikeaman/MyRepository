package telran.ashkelon2018.forum.dto;

import lombok.Getter;

@Getter
public class DatePeriodDto {
	String from;
	String to;

}
